
using Microsoft.AspNetCore.Mvc;
using Temporalio.Client;
using TemporalApp.Workflows;

[ApiController]
[Route("api/[controller]")]
public class ProfileController : ControllerBase
{
    private readonly ITemporalClient _temporalClient;
    public ProfileController(ITemporalClient client) => _temporalClient = client;

    [HttpPut]
    public async Task<IActionResult> SaveProfile([FromBody] ProfileData profile)
    {
        await _temporalClient.StartWorkflowAsync(
            (ProfileWorkflow wf) => wf.Run(profile),
            new(id: Guid.NewGuid().ToString(), taskQueue: "profile-task-queue")
        );
        return Ok();
    }
}
