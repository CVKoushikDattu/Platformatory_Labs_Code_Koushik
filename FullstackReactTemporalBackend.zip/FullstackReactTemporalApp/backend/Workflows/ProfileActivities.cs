
using System.Net.Http;
using System.Net.Http.Json;

public class ProfileActivities
{
    public async Task SaveToDatabase(ProfileData data)
    {
        Console.WriteLine("Saved to DB: " + data.FirstName);
    }

    public async Task UpdateCrudCrud(ProfileData data)
    {
        using var client = new HttpClient();
        await client.PostAsJsonAsync("https://crudcrud.com/api/YOUR_ENDPOINT/profile", data);
    }
}
