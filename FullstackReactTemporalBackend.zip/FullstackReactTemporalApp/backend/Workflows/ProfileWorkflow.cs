
using Temporalio.Workflows;
using System.Net.Http.Json;

[Workflow]
public class ProfileWorkflow
{
    [WorkflowRun]
    public async Task Run(ProfileData data)
    {
        await Workflow.ExecuteActivityAsync(
            (ProfileActivities act) => act.SaveToDatabase(data),
            new() { ScheduleToCloseTimeout = TimeSpan.FromSeconds(10) }
        );
        await Workflow.SleepAsync(TimeSpan.FromSeconds(10));
        await Workflow.ExecuteActivityAsync(
            (ProfileActivities act) => act.UpdateCrudCrud(data),
            new() { ScheduleToCloseTimeout = TimeSpan.FromSeconds(10) }
        );
    }
}
