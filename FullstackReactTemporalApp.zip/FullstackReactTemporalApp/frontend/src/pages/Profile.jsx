
import React, { useState } from "react";
import axios from "axios";

export default function Profile() {
  const [form, setForm] = useState({ firstName: "", lastName: "", phone: "", city: "", pincode: "" });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const saveProfile = async () => {
    await axios.put("http://localhost:5000/api/profile", form);
  };

  return (
    <div className="p-10 max-w-md mx-auto">
      <h1 className="text-xl font-semibold mb-4">Edit Profile</h1>
      {Object.entries(form).map(([key, val]) => (
        <input
          key={key}
          className="block border mb-2 w-full p-2"
          name={key}
          value={val}
          placeholder={key}
          onChange={handleChange}
        />
      ))}
      <button className="bg-green-600 text-white p-2 mt-4" onClick={saveProfile}>Save</button>
    </div>
  );
}
