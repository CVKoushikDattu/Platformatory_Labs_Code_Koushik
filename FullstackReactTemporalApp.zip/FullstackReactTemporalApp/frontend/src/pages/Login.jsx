
import React from "react";
export default function Login() {
  const loginWithRedirect = () => {
    window.location.href = "https://your-oidc-provider.com/auth";
  };
  return (
    <div className="p-10 text-center">
      <h1 className="text-2xl font-bold">Login</h1>
      <button className="bg-blue-500 text-white p-2 mt-4" onClick={loginWithRedirect}>
        Login with OIDC
      </button>
    </div>
  );
}
